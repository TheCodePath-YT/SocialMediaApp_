import commentModel from "./comment.model.js";
import postModel from "../post/post.model.js";

export class commentController {
  getAllComments(req,res) {
    const userID = req.userID;
    const postId = req.params.id;
    const items = commentModel.getAllComment(userID,postId);
    return res.status(200).send(items);

}
    addNewComment(req,res){
      
      const postId = req.params.id;
      const {content} = req.body;
      console.log(req.body)
      const post = postModel.getall();
      console.log(post)
      post.findIndex((item)=>{
        if (item.postId == postId) {
          let newComment=commentModel.add(postId,req.userID,content);
          return res.status(201).json(newComment);
        
      }else{
        return res.status(401).json({message:"Post not found"});
         
      }});
    }
   
    updateComment(req, res) {
      const commentId = req.params.id;
      const userID =  req.userID;
      const { postId, content} = req.body;
      const item = commentModel.updatecomment(postId,userID, content,commentId);
      console.log(item);
      if (!item) {
          return res.status(400).send('Uff sorry, comment Not Found !!');
      } else {
          return res.status(200).send(item);
      }
  
  }
    deleteComment(req,res){
        const userID = req.userID;
        const commentId = req.params.id;
      const error =  commentModel.delete(commentId , userID);
      if(error){
        return res.status(404).send(error);
      }
      return res.status(200).send('cart Item is removed');
    }

}