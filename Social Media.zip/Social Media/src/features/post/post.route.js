import express from 'express'  ;
import { postItemsController } from './post.controller.js';
import { upload } from '../../middleware/fileUpload.middleware.js';

const postRouter = express.Router() ;
// @route   POST api/v1/users/:userId/carts
// @desc    Add item to user's shopping cart
// @access  Private
const postItemsControllers = new postItemsController();
//localhost:3200/api/cartItems?productId=1&quantity=2
postRouter.delete("/:id",postItemsControllers.delete)
postRouter.post('/',postItemsControllers.add);
postRouter.get('/all',postItemsControllers.getAll);
postRouter.get('/:id',postItemsControllers.getbyuser);
postRouter.put('/:id',postItemsControllers.update);
postRouter.get('/name/:id',postItemsControllers.get);

export default postRouter;