//productId , userID , quantity

export default class postModel{
    constructor(postId,userId,caption,imageUrl){
        this.postId=postId;
        this.userId=userId;
        this.caption = caption;
        this.imageUrl = imageUrl;
        // this.id=id;
    }
   static add(postId,userId,caption,imageUrl){
        const postItem = new postModel(postId,userId,caption,imageUrl);
       postItem.id = post.length+1;
        post.push(postItem);
        return postItem;
    }
    static updatepost(postId, userId, caption, imageUrl) {
        const itemIndex = post.findIndex((i) => i.postId == postId || i.userId == userId);
        console.log(itemIndex)
        if (itemIndex !== -1) {
            post[itemIndex].caption = caption;
            post[itemIndex].imageUrl = imageUrl;
            console.log( post[itemIndex])
            return post[itemIndex];
        } else {
            return "not found";
        }
    }
    static getall(){
      return post;
    }
    static getpost(postID){
        console.log(postID)
      return post.find((i) => i.postId == postID);

    }
    static get(userID){
        console.log(userID)
      return post.filter((i) => i.userId == userID);

    }
    static delete(postItemId , userID){
        const postItemIndex = post.find((i)=> i.id==postItemId && i.userId==userID);
        if(postItemIndex == -1){
            return 'Item not found';
        }
        else{
           post.splice(postItemIndex, 1);
        }
    }
}
 let post = [
    new postModel(1,2,"This is my 1st post", " data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAP//Z") ,
    new postModel(2,1,"this is new post","data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2RP//Z"),
    new postModel(3,3,"this is new post","data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2RP//Z"),
 ];