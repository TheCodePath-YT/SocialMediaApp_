import postModel from "./post.model.js";
export class postItemsController {
    add(req,res){
        const {postId,caption,imageUrl} = req.query;
        console.log(res.body);
        const userID = req.userID;
     var result = postModel.add(postId,userID,caption,imageUrl);
     console.log(result);
        res.status(200).send('Cart is updated');
    }
 
    getAll(req,res) {
      const items = postModel.getall();
      console.log(items)
      return res.status(200).send(items);

  }
    get(req,res) {
        const userID = req.params.id;
        const items = postModel.get(userID);
        console.log(items)
        return res.status(200).send(items);

    }
    getbyuser(req,res) {
      const postID = req.params.id;
      const items = postModel.getpost(postID);
      console.log(items)
      if(!items || items == null){
        return res.status(400).send('Uff sorry , Post Not Found !!')
      }
      else{
        return res.status(200).send(items);
        
      }

  }
  update(req, res) {
    const postId = req.params.id;
    const { userId, caption, imageUrl } = req.body;
    const item = postModel.updatepost(postId, userId, caption, imageUrl);
    console.log(item);
    if (!item) {
        return res.status(400).send('Uff sorry, Post Not Found !!');
    } else {
        return res.status(200).send(item);
    }

}
    delete(req,res){
        const userID = req.userID;
        const postItemId = req.params.id;
      const error =  postModel.delete(postItemId , userID);
      if(error){
        return res.status(404).send(error);
      }
      return res.status(200).send('Post is removed');
    }
}