import express from 'express'  ;
import { likeController } from './like.controller.js';
import { upload } from '../../middleware/fileUpload.middleware.js';

const likeRouter = express.Router() ;
// @route   POST api/v1/users/:userId/carts
// @desc    Add item to user's shopping cart
// @access  Private
const likeControllers = new likeController();
//localhost:3200/api/cartItems?productId=1&quantity=2
likeRouter.get('/:id',likeControllers.getLikesForPost);
likeRouter.get('/toggle/:id',likeControllers.toggleLikeForPost);


export default likeRouter;