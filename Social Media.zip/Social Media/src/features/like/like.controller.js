

import {findLikesByPostId, findLike, removeLike, addLike } from "./like.model.js";


// GET /likes/:postId
export class likeController {
getLikesForPost(req, res) {
  const postId = req.params.id;
  const likes = findLikesByPostId(postId);
  res.json(likes);
}

// GET /toggle/:postId

 toggleLikeForPost(req, res) {
  const postId = req.params.id;
  const userId = req.userId; // Assuming user is authenticated and userId is available in req.user
  
  const existingLike = findLike(postId, userId);
  
  if (existingLike) {
    removeLike(postId, userId);
    res.json({ message: 'Like removed' });
  } else {
    addLike(postId, userId);
    res.json({ message: 'Like added' });
  }
}
}
